# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


$key = q/{_inline}rangle{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="9" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img2.gif"
 ALT="$\rangle$">|; 

$key = q/{_inline}sim{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="15" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="img4.gif"
 ALT="$\sim$">|; 

$key = q/{_inline}langle{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="9" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$\langle$">|; 

$key = q/{figure}centerlinepsfigfigure=assign1fig.eps{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="582" HEIGHT="312"
 SRC="img3.gif"
 ALT="\begin{figure}
\centerline{
\psfig {figure=assign1fig.eps}
}\end{figure}">|; 

1;


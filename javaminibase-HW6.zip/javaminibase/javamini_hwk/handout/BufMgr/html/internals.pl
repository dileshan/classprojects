# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate internals original text with physical files.


$key = q/assign1fig/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate labels original text with physical files.


$key = q/assign1fig/;
$external_labels{$key} = "$URL/" . q|node3.html|; 
$noresave{$key} = "$nosave";

1;


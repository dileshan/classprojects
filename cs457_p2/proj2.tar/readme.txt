Names: Matt Floyd, Tai Tran, Matt Desilvey

Instructions for running the resolver:
	1) type: make where the makefile lies
	2) The program takes one arugment which is the desired web site the user wants
		-Example:  >resolver www.google.com

Output:
	The program will not output the CNAME records,
	but will print out the ip address of the
	internet address that was typed in.

	Example: www.google.com is 64.233.161.9
